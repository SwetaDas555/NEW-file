import hashlib
import importlib.util
from pathlib import Path


MODULE_PATH = Path(__file__).resolve().parents[1] / "integrity_check.py"
SPEC = importlib.util.spec_from_file_location("integrity_check", MODULE_PATH)
integrity = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(integrity)


def test_sha256_matches_hashlib(tmp_path):
    file_path = tmp_path / "sample.log"
    file_path.write_bytes(b"example log entry\n")
    assert integrity.sha256_file(file_path) == hashlib.sha256(
        b"example log entry\n"
    ).hexdigest()


def test_collect_files_single_file(tmp_path):
    file_path = tmp_path / "sample.log"
    file_path.write_text("test", encoding="utf-8")
    assert integrity.collect_files(file_path) == [file_path.resolve()]


def test_collect_files_directory(tmp_path):
    (tmp_path / "one.log").write_text("one", encoding="utf-8")
    (tmp_path / "two.log").write_text("two", encoding="utf-8")
    found = integrity.collect_files(tmp_path)
    assert len(found) == 2
    assert all(path.is_file() for path in found)
