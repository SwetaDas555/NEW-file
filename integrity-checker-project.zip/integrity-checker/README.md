# File Integrity Checker

A lightweight Python command-line tool that calculates SHA-256 hashes for files, stores a baseline, and reports modifications, missing files, and untracked files.

## Requirements

- Python 3.9 or later
- Kali Linux, Debian, Ubuntu, or another Python-supported operating system
- No third-party packages required

## Project structure

```text
integrity-checker/
├── integrity_check.py
├── README.md
├── LICENSE
├── .gitignore
├── samples/
│   ├── app.log
│   └── auth.log
├── tests/
│   └── test_integrity_check.py
└── reports/
    └── .gitkeep
```

The baseline is stored outside the project at `~/.integrity-checker/baseline.json`.

## Quick start

```bash
python3 --version
chmod +x integrity_check.py

# Initialize a baseline for sample logs
python3 integrity_check.py init samples

# Check the files
python3 integrity_check.py check samples

# Simulate a change in your own test log
echo "Test modification" >> samples/app.log
python3 integrity_check.py check samples

# Accept a verified, authorized change for one file
python3 integrity_check.py update samples/app.log

# Review baseline metadata
python3 integrity_check.py status
```

## Commands

- `init PATH`: create or refresh baseline hashes for files under a file or directory path. Existing entries outside the selected path are retained.
- `check PATH`: compare tracked files and report modified, missing, and untracked files.
- `update FILE`: update the baseline for one existing file after an authorized change.
- `status`: show baseline location, tracked-file count, and timestamps.

Exit codes:
- `0`: successful operation / no discrepancies found by `check`
- `1`: discrepancies found, or no files were available to initialize
- `2`: operational error, invalid path, or missing matching baseline entries

## Security notes and limitations

SHA-256 detects content changes only when compared against a trusted baseline. It does not prove who made a change or when the change occurred. A person who can modify both monitored files and the baseline may be able to hide tampering. For real investigations, keep a protected baseline copy on a separate system or protected storage, restrict update permissions, and retain independent audit records. This tool performs checks when invoked; it is not continuous monitoring. Files can also change while being read, and this educational version does not provide a forensic chain-of-custody guarantee.

Use only on files and systems you are authorized to monitor. Test with the supplied sample logs, not live production logs.
