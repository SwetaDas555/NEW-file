#!/usr/bin/env python3
"""File Integrity Checker: SHA-256 baseline creation and tamper detection."""
import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

BASELINE_DIR = Path.home() / ".integrity-checker"
BASELINE_FILE = BASELINE_DIR / "baseline.json"


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_files(target):
    target = Path(target).expanduser()
    if target.is_symlink():
        raise ValueError("Symbolic links are not accepted as input.")
    target = target.resolve()
    if target.is_file():
        return [target]
    if target.is_dir():
        results = []
        for item in target.rglob("*"):
            if item.is_symlink():
                continue
            if item.is_file():
                results.append(item.resolve())
        return sorted(set(results))
    raise FileNotFoundError(f"Path does not exist: {target}")


def load_baseline():
    if not BASELINE_FILE.exists():
        return {"version": 1, "created_at": timestamp(), "updated_at": None, "files": {}}
    try:
        data = json.loads(BASELINE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot read baseline: {exc}") from exc
    if data.get("version") != 1 or not isinstance(data.get("files"), dict):
        raise RuntimeError("Baseline format is invalid or unsupported.")
    return data


def save_baseline(data):
    BASELINE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(BASELINE_DIR, 0o700)
    fd, temp_name = tempfile.mkstemp(prefix=".baseline-", suffix=".tmp", dir=BASELINE_DIR)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_name, 0o600)
        os.replace(temp_name, BASELINE_FILE)
        os.chmod(BASELINE_FILE, 0o600)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def command_init(target):
    paths = collect_files(target)
    if not paths:
        print("No regular files found.")
        return 1
    baseline = load_baseline()
    now = timestamp()
    for path in paths:
        baseline["files"][str(path)] = {"sha256": sha256_file(path), "updated_at": now}
    baseline["updated_at"] = now
    save_baseline(baseline)
    print(f"Baseline initialized for {len(paths)} file(s).")
    print(f"Baseline location: {BASELINE_FILE}")
    print("Security note: protect or externally store a trusted copy of the baseline.")
    return 0


def command_check(target):
    baseline = load_baseline()
    entries = baseline["files"]
    target_path = Path(target).expanduser().resolve()
    current_paths = {str(path) for path in collect_files(target)}
    if not entries:
        print("ERROR: Baseline is empty. Run init first.")
        return 2

    selected = {
        name: entry for name, entry in entries.items()
        if Path(name) == target_path or (target_path.is_dir() and target_path in Path(name).parents)
    }
    if not selected:
        print("ERROR: No baseline entries match this path. Run init first.")
        return 2

    modified = missing = unchanged = 0
    for name, entry in sorted(selected.items()):
        path = Path(name)
        if not path.is_file():
            print(f"MISSING:     {name}")
            missing += 1
            continue
        try:
            actual = sha256_file(path)
        except OSError as exc:
            print(f"ERROR:       {name}: {exc}")
            modified += 1
            continue
        if actual != entry.get("sha256"):
            print(f"MODIFIED:    {name}")
            print(f"  expected: {entry.get('sha256')}")
            print(f"  actual:   {actual}")
            modified += 1
        else:
            print(f"UNMODIFIED:  {name}")
            unchanged += 1

    untracked = current_paths - set(entries)
    for name in sorted(untracked):
        print(f"UNTRACKED:   {name}")

    print("\nIntegrity summary")
    print(f"Unmodified: {unchanged}")
    print(f"Modified/errors: {modified}")
    print(f"Missing: {missing}")
    print(f"Untracked: {len(untracked)}")
    if modified or missing or untracked:
        print("Status: DISCREPANCIES FOUND")
        return 1
    print("Status: OK")
    return 0


def command_update(target):
    path_arg = Path(target).expanduser()
    if path_arg.is_symlink():
        print("ERROR: Symbolic links are not accepted.")
        return 2
    path = path_arg.resolve()
    if not path.is_file():
        print("ERROR: update requires an existing regular file.")
        return 2
    baseline = load_baseline()
    if str(path) not in baseline["files"]:
        print("ERROR: File is not in the baseline. Run init on its file or directory first.")
        return 2
    now = timestamp()
    baseline["files"][str(path)] = {"sha256": sha256_file(path), "updated_at": now}
    baseline["updated_at"] = now
    save_baseline(baseline)
    print(f"Baseline updated for: {path}")
    print("Confirm the change was authorized before updating.")
    return 0


def command_status():
    baseline = load_baseline()
    print(f"Baseline: {BASELINE_FILE}")
    print(f"Tracked files: {len(baseline['files'])}")
    print(f"Created at: {baseline.get('created_at', 'unknown')}")
    print(f"Last updated: {baseline.get('updated_at') or 'never'}")
    return 0


def build_parser():
    parser = argparse.ArgumentParser(
        prog="integrity-check",
        description="Verify file integrity using SHA-256 hashes.",
        epilog="Examples: integrity-check init ./samples; integrity-check check ./samples",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("init", "check", "update"):
        sub = subparsers.add_parser(name, help=f"{name} file or directory")
        sub.add_argument("path", help="Path to a file or directory")
    subparsers.add_parser("status", help="Show baseline status")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            return command_init(args.path)
        if args.command == "check":
            return command_check(args.path)
        if args.command == "update":
            return command_update(args.path)
        if args.command == "status":
            return command_status()
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
