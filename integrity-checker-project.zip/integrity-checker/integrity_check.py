#!/usr/bin/env python3
"""File Integrity Checker: detect changes to files using SHA-256."""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

BASELINE_DIR = Path.home() / ".integrity-checker"
BASELINE_FILE = BASELINE_DIR / "baseline.json"


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_files(target):
    supplied = Path(target).expanduser()
    if supplied.is_symlink():
        raise ValueError("Symbolic links are not supported.")
    target = supplied.resolve()
    if target.is_file():
        return [target]
    if target.is_dir():
        return sorted(
            item.resolve() for item in target.rglob("*")
            if not item.is_symlink() and item.is_file()
        )
    raise FileNotFoundError(f"Path does not exist: {target}")


def load_baseline():
    if not BASELINE_FILE.exists():
        return {"version": 1, "created_at": timestamp(), "updated_at": timestamp(), "files": {}}
    try:
        data = json.loads(BASELINE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read baseline: {exc}") from exc
    if data.get("version") != 1 or not isinstance(data.get("files"), dict):
        raise RuntimeError("Baseline format is invalid or unsupported.")
    return data


def save_baseline(data):
    BASELINE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(BASELINE_DIR, 0o700)
    fd, temporary_name = tempfile.mkstemp(prefix=".baseline-", dir=BASELINE_DIR, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary_name, 0o600)
        os.replace(temporary_name, BASELINE_FILE)
        os.chmod(BASELINE_FILE, 0o600)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)


def command_init(target):
    files = collect_files(target)
    if not files:
        print("No regular files found.")
        return 1
    baseline = load_baseline()
    for path in files:
        baseline["files"][str(path)] = {
            "sha256": sha256_file(path),
            "updated_at": timestamp(),
        }
    baseline["updated_at"] = timestamp()
    save_baseline(baseline)
    print(f"Baseline initialized for {len(files)} file(s).")
    print(f"Baseline location: {BASELINE_FILE}")
    print("Keep a trusted baseline copy separate from the monitored system.")
    return 0


def command_check(target):
    target_input = Path(target).expanduser()
    if target_input.is_symlink():
        raise ValueError("Symbolic links are not supported.")
    target_path = target_input.resolve()
    baseline = load_baseline()
    entries = baseline["files"]
    if not entries:
        print("ERROR: Baseline is empty. Run init first.")
        return 2

    if target_path.is_file():
        selected = {str(target_path): entries[str(target_path)]} if str(target_path) in entries else {}
    elif target_path.is_dir():
        selected = {
            name: entry for name, entry in entries.items()
            if target_path == Path(name) or target_path in Path(name).parents
        }
    else:
        raise FileNotFoundError(f"Path does not exist: {target_path}")

    if not selected:
        print("ERROR: No baseline entries match this path. Run init first.")
        return 2

    current_files = {str(path) for path in collect_files(target_path)}
    modified = missing = unchanged = errors = 0

    for name, entry in sorted(selected.items()):
        path = Path(name)
        if not path.is_file():
            print(f"MISSING:    {name}")
            missing += 1
            continue
        try:
            actual = sha256_file(path)
        except OSError as exc:
            print(f"ERROR:      {name}: {exc}")
            errors += 1
            continue
        if actual != entry.get("sha256"):
            print(f"MODIFIED:   {name}")
            print(f"  Expected: {entry.get('sha256', 'missing hash')}")
            print(f"  Actual:   {actual}")
            modified += 1
        else:
            print(f"UNMODIFIED: {name}")
            unchanged += 1

    untracked = sorted(current_files - set(entries))
    for name in untracked:
        print(f"UNTRACKED:  {name}")

    print("\nIntegrity summary")
    print(f"Unmodified: {unchanged}")
    print(f"Modified:   {modified}")
    print(f"Missing:    {missing}")
    print(f"Errors:     {errors}")
    print(f"Untracked:  {len(untracked)}")
    if modified or missing or errors or untracked:
        print("Status: DISCREPANCIES FOUND")
        return 1
    print("Status: OK")
    return 0


def command_update(target):
    supplied = Path(target).expanduser()
    if supplied.is_symlink():
        raise ValueError("Symbolic links are not supported.")
    path = supplied.resolve()
    if not path.is_file():
        raise FileNotFoundError("update requires an existing regular file.")
    baseline = load_baseline()
    baseline["files"][str(path)] = {
        "sha256": sha256_file(path),
        "updated_at": timestamp(),
    }
    baseline["updated_at"] = timestamp()
    save_baseline(baseline)
    print(f"Baseline updated: {path}")
    print("Only do this after verifying that the change was authorized.")
    return 0


def command_status():
    baseline = load_baseline()
    print(f"Baseline: {BASELINE_FILE}")
    print(f"Tracked files: {len(baseline['files'])}")
    print(f"Created: {baseline.get('created_at', 'unknown')}")
    print(f"Last updated: {baseline.get('updated_at', 'unknown')}")
    return 0


def build_parser():
    parser = argparse.ArgumentParser(
        description="Detect file changes using SHA-256 integrity baselines."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("init", "check", "update"):
        sub = subparsers.add_parser(command)
        sub.add_argument("path", help="Path to one file or a directory")
    subparsers.add_parser("status", help="Show baseline details")
    return parser


def main():
    args = build_parser().parse_args()
    try:
        if args.command == "init":
            return command_init(args.path)
        if args.command == "check":
            return command_check(args.path)
        if args.command == "update":
            return command_update(args.path)
        if args.command == "status":
            return command_status()
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
